package com.stackroute.datamunger.query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

//this class will be acting as the DataSet containing multiple rows
public class DataSet extends LinkedHashMap<Long, Row> {

	
	
	//this method will performing the sort on the dataset
	public DataSet sort(RowDataTypeDefinitions dataTypes, String columnName) {
	
		return null;
	}

	
}