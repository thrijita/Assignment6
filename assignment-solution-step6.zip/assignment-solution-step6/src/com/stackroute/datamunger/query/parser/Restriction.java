package com.stackroute.datamunger.query.parser;

public class Restriction {
	
	private String PropertyName,Condition,PropertyValue;

	public String getPropertyName() {
		return PropertyName;
	}

	public void setPropertyName(String propertyName) {
		PropertyName = propertyName;
	}

	public String getCondition() {
		return Condition;
	}

	public void setCondition(String condition) {
		Condition = condition;
	}

	public String getPropertyValue() {
		return PropertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		PropertyValue = propertyValue;
	}	
	

}